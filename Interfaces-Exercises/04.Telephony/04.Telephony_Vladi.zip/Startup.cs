﻿namespace _04.Telephony
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using _04.Telephony.Entities;

    class Startup
    {
        static void Main(string[] args)
        {
            var numbers = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var sites = Console.ReadLine().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var smartphone = new Smartphone(numbers, sites);

            Console.Write(smartphone.ToString());
        }
    }
}
