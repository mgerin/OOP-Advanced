﻿namespace _04.Telephony.Entities.Interfaces
{
    using System.Collections.Generic;

    public interface ICall
    {
        ICollection<string> Contacts { get; }

        string Call(string number);
    }
}
