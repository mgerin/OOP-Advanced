﻿namespace _04.Telephony.Entities.Interfaces
{
    using System.Collections.Generic;

    public interface IBrowse
    {
        ICollection<string> Sites { get; }

        string Browse(string url);
    }
}
